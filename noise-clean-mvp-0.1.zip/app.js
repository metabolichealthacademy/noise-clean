const analyzeButton = document.getElementById("analyzeButton");
const claimInput = document.getElementById("claim");
const results = document.getElementById("results");
const resultLabel = document.getElementById("resultLabel");
const scoreElement = document.getElementById("score");
const reasonsElement = document.getElementById("reasons");
const flagsElement = document.getElementById("claimFlags");
const sourcesElement = document.getElementById("sources");

analyzeButton.addEventListener("click", analyzeClaim);

async function analyzeClaim() {
  const claim = claimInput.value.trim();

  if (!claim) {
    alert("Please enter a health claim first.");
    return;
  }

  let score = 5;
  const reasons = [];
  const flags = [];
  const lowerClaim = claim.toLowerCase();

  const absoluteWords = [
    "cure", "cures", "cured", "guaranteed", "always", "never",
    "completely", "100%", "reverses", "reverse"
  ];

  if (absoluteWords.some(word => lowerClaim.includes(word))) {
    score -= 2;
    reasons.push("The claim contains absolute or unusually strong language.");
    flags.push("Absolute claim");
  }

  const treatmentWords = [
    "treat", "treatment", "prevent", "prevents",
    "heal", "heals", "medicine", "medication"
  ];

  if (treatmentWords.some(word => lowerClaim.includes(word))) {
    reasons.push("The claim concerns treatment or prevention and therefore requires appropriate medical evidence.");
    flags.push("Treatment/prevention claim");
  }

  const healthTerms = [
    "diabetes", "prediabetes", "insulin resistance", "obesity",
    "blood pressure", "cholesterol", "heart disease", "stroke",
    "cancer", "fatty liver", "sleep apnea", "pcos"
  ];

  if (healthTerms.some(term => lowerClaim.includes(term))) {
    reasons.push("The statement concerns a recognized health condition.");
    flags.push("Health-related claim");
  }

  const promotionalWords = [
    "miracle", "secret", "hack", "magic", "detox", "instant", "shocking"
  ];

  if (promotionalWords.some(word => lowerClaim.includes(word))) {
    score -= 1;
    reasons.push("The wording contains promotional or sensational language.");
    flags.push("Promotional language");
  }

  score = Math.max(0, Math.min(10, score));

  let label;
  if (score >= 8) label = "WELL SUPPORTED";
  else if (score >= 6) label = "PARTIALLY SUPPORTED";
  else if (score >= 4) label = "INSUFFICIENT EVIDENCE";
  else if (score >= 2) label = "MISLEADING";
  else label = "UNSUPPORTED";

  if (reasons.length === 0) {
    reasons.push("The prototype did not detect major warning characteristics in the wording.");
  }

  displayResult(score, label, reasons, flags);
}

function displayResult(score, label, reasons, flags) {
  results.classList.remove("hidden");
  resultLabel.textContent = label;
  scoreElement.textContent = score;

  reasonsElement.innerHTML = "";
  reasons.forEach(reason => {
    const li = document.createElement("li");
    li.textContent = reason;
    reasonsElement.appendChild(li);
  });

  flagsElement.innerHTML = "";

  if (flags.length === 0) {
    const flag = document.createElement("span");
    flag.className = "flag";
    flag.textContent = "No major wording flags detected";
    flagsElement.appendChild(flag);
  } else {
    flags.forEach(flagText => {
      const flag = document.createElement("span");
      flag.className = "flag";
      flag.textContent = flagText;
      flagsElement.appendChild(flag);
    });
  }

  loadSources();
  results.scrollIntoView({ behavior: "smooth" });
}

async function loadSources() {
  try {
    const response = await fetch("sources.json");
    if (!response.ok) throw new Error("Could not load source library.");

    const sources = await response.json();
    sourcesElement.innerHTML = "";

    sources.forEach(source => {
      const div = document.createElement("div");
      div.className = "source";

      const name = document.createElement("strong");
      name.textContent = source.name;

      const meta = document.createElement("small");
      meta.textContent = `${source.type} · Tier ${source.tier}`;

      const br = document.createElement("br");

      const link = document.createElement("a");
      link.href = source.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Visit source";

      div.append(name, meta, br, link);
      sourcesElement.appendChild(div);
    });
  } catch (error) {
    sourcesElement.textContent = "Source library could not be loaded.";
    console.error(error);
  }
}
